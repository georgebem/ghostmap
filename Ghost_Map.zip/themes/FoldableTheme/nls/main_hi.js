// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See http://js.arcgis.com/3.15/esri/copyright.txt and http://www.arcgis.com/apps/webappbuilder/copyright.txt for details.
//>>built
define({"themes/FoldableTheme/nls/strings":{_themeLabel:"\u092b\u094b\u0932\u094d\u0921\u0947\u092c\u0932 \u0925\u0940\u092e",_layout_default:"\u0921\u093f\u095e\u0949\u0932\u094d\u091f \u0930\u0942\u092a\u0930\u0947\u0916\u093e",_layout_layout1:"\u0930\u0942\u092a\u0930\u0947\u0916\u093e 1",_localized:{}}});